from setuptools import setup, find_packages

setup(
    name='diploma-frontend',
    version='0.6',
    packages=find_packages(),
    include_package_data=True,  # Это важно!
    description='Frontend for diploma project',
    install_requires=[
        'Django>=4.2',
    ],
)